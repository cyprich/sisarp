﻿namespace Uniza.CSharp.Generics.Tools;

public class Swapper
{
    public static void Swap(int number1, int number2)
    {
        (number2, number1) = (number1, number2);
    }

    public static void Swap(double number1, double number2)
    {
        (number2, number1) = (number1, number2);
    }

    public static void Swap(string str1, string str2)   
    {
        (str2, str1) = (str1, str2);
    }

    // TODO: Úloha 1.2 - Pridajte generickú metódu na prehodenie hodnôt a použite ju v programe.

}
